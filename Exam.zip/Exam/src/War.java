import java.util.Random;
import java.util.Scanner;

public class War {
	private static Random rand = new Random();
	private static String[] cards = new String[]{"2","3","4","5","6","7","8","9","10","J","Q","K"};
	private static String ans1;
	private static String ans2;
	
	//randomize card
	public static String drawCard(){
		return cards[rand.nextInt(cards.length)];
	}
	
	
	//someone won! finish game
	public static void endGame(int bet, String c1, String c2){
		String result1 = "loses";
		String result2 = "loses";
		
		//start comparing the numbers - 10 is less than 2 in this case
		if(c1.compareTo("9") <= 0 && c2.compareTo("9") <=0){
			
			//10 is the highest numerical and the confusing value
			if(c1 == "10"){
				result1 = "wins";
			}
			else if(c2 == "10"){
				result2 = "wins";
			}
			//now compare as if comparing integers
			else if(c1.compareTo(c2) < 0){
				result2 = "wins";
			}
			else{
				result1 = "wins";
			}
		}
		//if one card is numeric at this point, it's the loser
		else if(c1.compareTo("9") <= 0){
			result2 = "wins";
		}
		else if(c2.compareTo("9") <= 0){
			result1 = "wins";
		}
		//now compare the alpha values
		else{
			if(c1 == "A"){
				result1 = "wins";
			}
			else if(c2 == "A" || c2 == "K"){
				result2 = "wins";
			}
			else if(c1 == "K" || c1 == "Q"){
				result1 = "wins";
			}
			//at this point, player2 must be Q and player1 must be J
			else{
				result2 = "wins";
			}			
		}
		System.out.println("Player 1 " + result1 + " $" + bet);
		System.out.println("Player 2 " + result2 + " $" + bet);
		
		System.out.println("Thank you for playing war.");
		System.exit(0);
	}

	public static void main(String [] args){
		Scanner in = new Scanner(System.in);
		String card1 = "2";
		String card2 = "2";
		boolean keepPlay = true;
		
		//make bet
		System.out.print("Player 1 Bet - $");
		int bet = in.nextInt();
		System.out.println(bet);
		
		//Player2 can stop game
		System.out.print("Player 2 Agree? ");
		String agree = in.nextLine();
		System.out.println(agree);
		System.out.println(" ");
		if(agree.toLowerCase() == "no"){
			keepPlay = false;
		}
		while(keepPlay == true){
			card1 = drawCard();
			card2 = drawCard();
			System.out.println("Player 1 Card - " + card1);
			System.out.println("Player 2 Card - " + card2);
			System.out.println(" ");
			
			//end game once the cards aren't equivalent
			if(card1 != card2){
				in.close();
				endGame(bet, card1, card2);
			}		
			
			//otherwise, allow users to decide whether or not to continue
			System.out.print("Ready to continue?");
			ans1 = in.nextLine();
			ans2 = in.nextLine();
			if(ans1.toLowerCase() == "no" || ans2.toLowerCase() == "no"){
				keepPlay = false;
			}
			if(keepPlay == false){
				System.out.println("No");
				System.out.println(" ");
			}
			else{
				System.out.println("Yes");
				System.out.println(" ");
			}
		}
		
		//game is over, no one really won or lost
		in.close();
		System.out.println("Thank you for playing war.");
		
	}
}