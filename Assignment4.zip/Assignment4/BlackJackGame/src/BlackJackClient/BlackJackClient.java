package BlackJackClient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import static java.lang.Thread.sleep;
import java.net.Socket;
import java.nio.CharBuffer;
import java.util.Scanner;

public class BlackJackClient {
    private Socket socket;
    private BufferedReader is;
    private PrintWriter os;
    private Scanner sc;
    private String name;
    public BlackJackClient(Socket _socket, BufferedReader _is, PrintWriter _os){
        this.socket=_socket;
        this.is=_is;
        this.os=_os;
        sc=new Scanner(System.in);
    }
    
    public void initializeGame() throws IOException{
        int input;
        String name = null, response = null;
        boolean isGameCreator=false;
        //Dealing with game options
        System.out.println("Please choose from the option below\n1) Start Game\n2) Join Game");
        do{
            input=sc.nextInt();
            sc.nextLine();
        }while(input<1 || input>2);
        this.os.println(input);
        
        //Dealing with noOfPlayers
        if(input==1){
            isGameCreator=true;
            System.out.println("Please choose the number of players in the game (1-3)");
            do{
                input=sc.nextInt();
                sc.nextLine();
            }while(input<1 || input>3);
            this.os.println(input);
        }
        
        //Dealing with gameName
        do{
            try{
                if(!isGameCreator)
                    System.out.println("Please enter the name of the game you wish to join");
                else
                    System.out.println("Please choose a name for your game");
                
                name=sc.nextLine();
                this.os.println(name);
                response=this.is.readLine();
                if(response.equals("Invalid name!")){
                    if(!isGameCreator)
                        System.err.println("Invalid choice! There is no on going games with this name");
                    else
                        System.out.println("Invalid choice! This game has alrady taken by another user");
                }
            }
            catch(Exception ex){
                System.err.println("Error! reading gameName from server");
            }
            
        }while(response.equals("Invalid name!"));
        
        //Dealing with playerName
        do{
            try{
                System.out.println("Please choose a username");
                name=sc.nextLine();
                this.os.println(name);
                response=this.is.readLine();
                if(response.equals("Invalid name!"))
                    System.err.println("Invalid choice! This username has alrady been taken by another user in this game");
            }
            catch(Exception ex){
                System.err.println("Error! reading gameName from server");
            }
            
        }while(response.equals("Invalid name!"));
        this.name=name;
        
        //this is true if user selet option 1 (start new game)
        if(!isGameCreator){
            //this message is displayed to players whoe join the game
            System.out.println("The game will start shortly, Waiting for other players to join...");
        }
        else{
            //This message is displayed to payers who start the game
            response=this.is.readLine();
            System.out.println(response);
        }
    }
    
    private void startGame() throws IOException{
        String request, response, name, chips;
        int bet=0;
        //Waiting for other players, when players are complete server send a message to start game
        do{
            response=this.is.readLine();
            if("your turn!".equals(response)){
                System.out.println("Its your turn to add cards to your hand");
                do{
                    System.out.println("Enter either '1' or 'stay' to stay\n Enter either '2' or 'hit' to hit.");
                    do{
                        request=this.sc.nextLine();
                    }while(!(request.equals("1")||request.equals("stay")||request.equals("2")||request.equals("hit")));
                    this.os.println(request);//sending user choise to server
                    response=this.is.readLine();
                    System.out.println(response);
                    response=this.is.readLine();
                    
                }while(!(request.equals("1")||request.equals("stay")) && !response.equals("stop"));
                
                
            }
            else if("make bet!".equals(response)){
                name=this.is.readLine();
                chips=this.is.readLine();
                System.out.println(name+", it is your turn to make a bet. Your chip total is "+chips);
                do{
                    bet=this.sc.nextInt();
                    sc.nextLine();
                }while(bet<=0 || bet>Integer.parseInt(chips));
                
                //sending bet to server
                this.os.println(Integer.toString(bet));
            }
            else if("message!".equals(response)){
                response=this.is.readLine();
                System.out.println(response);
            }
            else if("status!".equals(response)){
                
                response=this.is.readLine();
                response=response.replace('#', '\n');
                System.out.println(response);
            }
                
        }while(!"end!".equals(response));
        
    }
    
    
    
    public static void main(String[] args) throws IOException {
        Socket clientSocket = null;
        String ipaddress;
        int port;
        Scanner sc=new Scanner(System.in);
        System.out.println("Welcome to Black Jack!");
        
        //This loop ensures ensures the server is accessed correctly
        do{
            System.out.println("Please enter the ipaddress!");
            ipaddress=sc.nextLine();
            System.out.println("Please enter the port");
            port=sc.nextInt();
            sc.nextLine();
            try{
                clientSocket=new Socket(ipaddress,port);
            }
            catch(Exception ex){
                System.err.println("Unable to connect to server with provided fields");
                try {
                    sleep(100);
                } catch (InterruptedException ex1) {
                    System.err.println(ex1.getMessage());
                }
            }
        }while(clientSocket==null);
        
        
        BufferedReader is=new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
        PrintWriter os=new PrintWriter(clientSocket.getOutputStream(),true);
        
        //Creating game instance
        BlackJackClient blackJackClient=new BlackJackClient(clientSocket, is, os);
        blackJackClient.initializeGame();
        blackJackClient.startGame(); 
        clientSocket.close();
    }  
}
