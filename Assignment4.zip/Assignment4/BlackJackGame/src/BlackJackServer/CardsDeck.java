/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BlackJackServer;

import static java.lang.Math.random;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;


public class CardsDeck
{
	private static String[] suits = { "hearts", "spades", "diamonds", "clubs" };
	private static String[] ranks  = { "Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King" };
        private Random rand;
        private int rank, suit;
        private HashMap<String, String> removed;

	public CardsDeck()
	{
            this.rand=new Random();
            this.removed=new HashMap<>();
	}

	public @Override String toString()
	{
            return ranks[rank] + " of " + suits[suit];
	}

	public int getRank() {
            return rank;
	}

	public int getSuit() {
            return suit;
	}
        
        public ArrayList<String> getRandomCard(){
            int num=0;
            do{
                num=rand.nextInt(52);
            }while(removed.containsKey(Integer.toString(num)));
            
            this.rank=num%13;
            this.suit=num/13;
            ArrayList<String> card=new ArrayList<>();
            removed.put(Integer.toString(num), this.toString());
            card.add(this.ranks[this.rank]);
            card.add(this.toString());
            //System.err.println(this.toString());
            return card;
        }

}
