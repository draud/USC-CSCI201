package BlackJackServer;

import java.io.BufferedReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

public class BlackJackPlayer {
    private Socket socket;//player socket
    private BufferedReader is;//input from socket
    private PrintWriter os;//output to socket
    private String name;
    private int chips;
    private int betChips;
    private boolean isBusted;//set to true if player is busted (point > 21)
    private ArrayList<String> cards;
    private ArrayList<String> cardsMsg;
    public BlackJackPlayer(String _name, Socket _socket, PrintWriter _os, BufferedReader _is){
        this.name=_name;
        this.socket=_socket;
        this.is=_is;
        this.os=_os;
        this.chips=500;//Initial chip for every player is 500
        this.cards=new ArrayList<>();
        this.cardsMsg=new ArrayList<>();
        this.isBusted=false;
    }
    
    //getter for player name
    public String getName(){
        return this.name;
    }
    
    //getter for player chips
    public int getChips(){
        return this.chips;
    }
    
    public void setChips(int _chips){
        this.chips=_chips;
    }
    
    public boolean getiSBusted(){
        return this.isBusted;
    }
    
    public void setiSBusted(boolean _isBusted){
        this.isBusted=_isBusted;
    }
    
    public void sendMessage(String _message){
        this.os.println(_message);//sending message to client
    }
    
    public void sendStatus(String _message){
        this.os.println(_message);//sending status to client
    }
    
    public PrintWriter getPrintWriter(){
        return this.os;
    }
    
    public int getBetChips(){
        return this.betChips;
    }
    
    public void setBetChips(int _betChips){
        this.betChips=_betChips;
    }
    
    //os => Input socket
    public BufferedReader getIs(){
        return this.is;
    }
    
    public void addCard(String _key, String _value){
        this.cards.add(_key);
        this.cardsMsg.add(_value);
    }
    
    public ArrayList<String> getCard(){
        return this.cards;
    }
    
    @Override
    public String toString(){
        boolean flag=false;
        String msg="---------------------------------------------------#";
        
        if(this.os!=null){
            msg+="Player: "+this.name+"#";
            msg+="Status:  "+this.getStatusMsg()+"#";
        }
        else{
            msg+="DEALER#";
        }
        
        msg+="Cards: | ";
        for(int i=0; i<this.cardsMsg.size(); ++i)
            if(this.os==null && !flag){
                flag=true;
                msg+=" ? | ";
            }
            else
                msg+=this.cardsMsg.get(i)+" | ";
        
        msg+="#";
        if(this.os!=null){
            msg+="Chips Total: "+this.chips+" | Bet Amount: "+this.betChips+"#";
        }
        
        msg+="---------------------------------------------------#";
        
        
        return msg;
    }
    
    
    //This function calculates the points of players
    public String getStatusMsg(){
        String msg="";
        boolean isAce=false;
        int points=0;
        int length=this.cards.size();
        for(int i=0; i<length; ++i){
            if(this.cards.get(i).equals("Ace")){
                isAce=true;
                points+=1;
            }else if(this.cards.get(i).equals("2")){
                points+=2;
            }else if(this.cards.get(i).equals("3")){
                points+=3;
            }else if(this.cards.get(i).equals("4")){
                points+=4;
            }else if(this.cards.get(i).equals("5")){
                points+=5;
            }else if(this.cards.get(i).equals("6")){
                points+=6;
            }else if(this.cards.get(i).equals("7")){
                points+=7;
            }else if(this.cards.get(i).equals("8")){
                points+=8;
            }else if(this.cards.get(i).equals("9")){
                points+=9;
            }else if(this.cards.get(i).equals("10")){
                points+=10;
            }else if(this.cards.get(i).equals("Jack")){
                points+=10;
            }else if(this.cards.get(i).equals("Queen")){
                points+=10;
            }else if(this.cards.get(i).equals("King")){
                points+=10;
            }
              
        }
        
        String status="";
        if(!isAce)
            status = Integer.toString(points);
        else
            status = Integer.toString(points)+" or "+ Integer.toString(points+10);

        return status;
    }
    
    public int getPoints(){
        boolean isAce=false;
        int points=0;
        int length=this.cards.size();
        for(int i=0; i<length; ++i){
            if(this.cards.get(i).equals("Ace")){
                isAce=true;
                points+=1;
            }else if(this.cards.get(i).equals("2")){
                points+=2;
            }else if(this.cards.get(i).equals("3")){
                points+=3;
            }else if(this.cards.get(i).equals("4")){
                points+=4;
            }else if(this.cards.get(i).equals("5")){
                points+=5;
            }else if(this.cards.get(i).equals("6")){
                points+=6;
            }else if(this.cards.get(i).equals("7")){
                points+=7;
            }else if(this.cards.get(i).equals("8")){
                points+=8;
            }else if(this.cards.get(i).equals("9")){
                points+=9;
            }else if(this.cards.get(i).equals("10")){
                points+=10;
            }else if(this.cards.get(i).equals("Jack")){
                points+=10;
            }else if(this.cards.get(i).equals("Queen")){
                points+=10;
            }else if(this.cards.get(i).equals("King")){
                points+=10;
            }
              
        }
        
        if(isAce){
            if(points+10 < 21)//pick which one won't bust
                points+=10;
        }
        
        return points;
    }
    
    public void resetState(){
        this.cards.clear();
        this.cardsMsg.clear();
        this.isBusted=false;
        this.betChips=0;
    }
    
}
