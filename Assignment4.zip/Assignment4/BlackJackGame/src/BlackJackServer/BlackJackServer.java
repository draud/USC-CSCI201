/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BlackJackServer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author master
 */
public class BlackJackServer {

    public static void main(String[] args) throws IOException {
        System.out.println("Welcome to the Black Jack Server!");
        Scanner sc = new Scanner(System.in);
        int port = 0;
        ServerSocket socket = null;
        //This loop ensure the validity/availability of port
        do{
            try{
                System.out.println("Please Enter a port");
                port=sc.nextInt();
                socket=new ServerSocket(port);
            }catch(Exception e){
                System.err.println("Invalid port number");
                sc.nextLine();
            }
        }while(socket==null);
        System.out.println("Successfully started the Black Jack server on port "+port);
        new BlackJackClub(socket).openClub();//Opening BlackJack Club
        socket.close();//Closing server socket
    }
    
}
