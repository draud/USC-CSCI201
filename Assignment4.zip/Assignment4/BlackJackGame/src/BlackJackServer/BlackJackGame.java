/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BlackJackServer;

import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author master
 */
public class BlackJackGame extends Thread{
    private final ArrayList<BlackJackPlayer> playerList;
    private final int noOfPlayers;
    private final String gameName;
    private final CardsDeck deck;
    private boolean isGameEnd;
    BlackJackGame(int _noOfPlayers, String _gameName){
        this.playerList=new ArrayList<>();
        this.noOfPlayers=_noOfPlayers;
        this.gameName=_gameName;
        this.deck=new CardsDeck();
        this.isGameEnd=false;
    }
    
    @Override
    public void run(){
        this.completePlayers();//first complete players for the game
        this.startGame();
    }
    
    private void completePlayers(){
        //System.out.println("completePlayers");
        //hold until players are complete
        do{
            try {
                //System.out.println(this.playerList.size()+":"+this.noOfPlayers);
                sleep(1000);
            } catch (InterruptedException ex) {
                System.err.println(ex.getMessage());
            }
        }while(this.playerList.size()<this.noOfPlayers);
        
        //Sending message to players when game players are complete
        this.sendMessageToAll("Let the game commence. Good luck to all players!");
        
        this.playerList.add(new BlackJackPlayer("Dealer", null, null, null));//Adding Dealer to player list
    }
    
    //This procedure hold our whole gmane logic
    private void startGame(){
        
        try{
            this.startRounds();
        }
        catch(Exception ex){
            ex.printStackTrace();
        }
        
    }
    
    private void shufflCards() throws IOException{
        ArrayList<String> card=null;
        //Dealer is shuffling cards
        this.sendMessageToAll("Dealer is shuffling cards..");
        for(int i=0; i<this.noOfPlayers+1; ++i){
            for(int j=0; j<2;++j){
                card=this.deck.getRandomCard();
                this.playerList.get(i).addCard(card.get(0), card.get(1));    
            }
        }
    }
    
    private void makeBet() throws IOException{
        //Making bets
        for(int i=0 ; i<this.noOfPlayers; ++i){
            //Informing other players who is making bet
            for(int j=0; j<this.noOfPlayers; ++j){
                if(i!=j){
                    this.playerList.get(j).sendMessage("message!");
                    this.playerList.get(j).sendMessage("It is "+this.playerList.get(i).getName()+"'s turn to make a bet.");
                }
            }
            
            //sending name of current player to bet
            this.playerList.get(i).sendMessage("make bet!");
            this.playerList.get(i).sendMessage(this.playerList.get(i).getName());
            this.playerList.get(i).sendMessage(Integer.toString(this.playerList.get(i).getChips()));
            this.playerList.get(i).setBetChips(Integer.parseInt(this.playerList.get(i).getIs().readLine()));
            
            //Informinng about players' bets
            for(int j=0; j<this.noOfPlayers; ++j){
                if(i!=j){
                    this.playerList.get(j).sendMessage("message!");
                    this.playerList.get(j).sendMessage(this.playerList.get(i).getName()+" bet "+this.playerList.get(i).getBetChips()+" chips");
                }
            }
        }
        
        //Sending Game Status
        String msg="";
        for(int i=0; i<this.noOfPlayers+1; ++i){
            msg+=this.playerList.get(i).toString();
        }
        
        this.sendStatusToAll(msg);
    }
    
    
    //Performs rounds throughout the game until one player loses all their chips
    private void startRounds() throws IOException{
        boolean stay=false;//user to exit from loop and end taking new cards
        ArrayList<String> card=null;
        String request=null;
        do{
            this.shufflCards();//shuffle cards
            this.makeBet();//making bets
            
            //Start round
            for(int i=0; i<this.noOfPlayers; ++i){
                stay=false;
                this.playerList.get(i).sendMessage("your turn!");
                this.sendMessageToAllExcept("It's "+this.playerList.get(i).getName()+" turn to add card to their hand", i);
                
                do{
                    request=this.playerList.get(i).getIs().readLine();
                    if(!(request.equals("1")||request.equals("stay"))){
                        card=this.deck.getRandomCard();
                        this.playerList.get(i).addCard(card.get(0), card.get(1));
                        if(this.playerList.get(i).getPoints()>21){
                            this.playerList.get(i).setiSBusted(true);
                            this.playerList.get(i).sendMessage("You busted. You lose "+this.playerList.get(i).getBetChips()+" chips");
                            this.playerList.get(i).sendMessage("stop");//stop hiting if user is busted
                            this.sendMessageToAllExcept(this.playerList.get(i).getName()+" busted. They lose "+this.playerList.get(i).getBetChips()+" chips",i);
                        }
                        else{
                            this.playerList.get(i).sendMessage("You hit. You are dealt with "+card.get(1));
                            this.sendMessageToAllExcept(this.playerList.get(i).getName()+" hit. They are dealt with "+card.get(1),i);
                            this.playerList.get(i).sendMessage("continue");//if user is not busted
                        }
                    }
                    else{
                        this.playerList.get(i).sendMessage("You stayed.");
                        this.sendMessageToAllExcept(this.playerList.get(i).getName()+" stayed.",i);
                        stay=true;
                    }
                    
                }while(!(request.equals("1")||request.equals("stay")) && !this.playerList.get(i).getiSBusted() && !stay);
                
            }
            
            //Now it's the dealer's turn to add vard to their hand
            this.sendMessageToAll("It is now time for the dealer to play.");
            while(this.playerList.get(this.noOfPlayers).getPoints()<17){
                card=this.deck.getRandomCard();
                this.playerList.get(this.noOfPlayers).addCard(card.get(0), card.get(1));
                this.sendMessageToAll("Dealer hit and they were dealt with "+card.get(1));
            }
            
            //Now it's time to end the round
            for(int i=0; i<this.noOfPlayers; ++i){
                if(this.playerList.get(i).getPoints()==21){
                    //he has black jack , double the chips
                    this.playerList.get(i).setChips(this.playerList.get(i).getChips()+(this.playerList.get(i).getBetChips()*2));
                    this.playerList.get(i).sendMessage("message!");
                    this.playerList.get(i).sendMessage("You had a black Jack. "+(this.playerList.get(i).getBetChips()*2)+" chips were added to your account.");
                    this.sendMessageToAllExcept(this.playerList.get(i).getName()+" had a Black Jack. "+(this.playerList.get(i).getBetChips()*2)+" chips were added to their total", i);
                }
                else if(this.playerList.get(i).getPoints()>21){
                    //he is busted, lose bet chips
                    this.playerList.get(i).setChips(this.playerList.get(i).getChips()-(this.playerList.get(i).getBetChips()));
                    this.playerList.get(i).sendMessage("message!");
                    this.playerList.get(i).sendMessage("You are busted. "+(this.playerList.get(i).getBetChips())+" chips were deducted from your account.");
                    this.sendMessageToAllExcept(this.playerList.get(i).getName()+" is busted. "+(this.playerList.get(i).getBetChips())+" chips were deducted from their total", i);

                    
                }
                else if(this.playerList.get(i).getPoints()==this.playerList.get(this.noOfPlayers).getPoints()){
                    //tied with the dealer, chips remain same
                    this.playerList.get(i).sendMessage("message!");
                    this.playerList.get(i).sendMessage("You tied with the dealer. Your chip total remains the same.");
                    this.sendMessageToAllExcept(this.playerList.get(i).getName()+" tied with the dealer. Their chip total remains the same", i);  
                }
                else if(this.playerList.get(i).getPoints()<this.playerList.get(this.noOfPlayers).getPoints()){
                    this.playerList.get(i).setChips(this.playerList.get(i).getChips()-(this.playerList.get(i).getBetChips()));
                    this.playerList.get(i).sendMessage("message!");
                    this.playerList.get(i).sendMessage("You had a sum less than the dealer's. "+(this.playerList.get(i).getBetChips())+" chips were deducted from your account.");
                    this.sendMessageToAllExcept(this.playerList.get(i).getName()+" had a sum less than the dealer's. "+(this.playerList.get(i).getBetChips())+" chips were deducted from their total", i);

                }
                
                if(this.playerList.get(i).getChips()==0){
                    //if one of player has chips equal to zero
                    isGameEnd=true;
                }
            }
 
            if(!isGameEnd){
                //getting ready for the second round
                this.resetPlayersState();
            }
        }while(!isGameEnd);
        
        //Declearing winner and Printing Winning message
        int winnerChips=Integer.MAX_VALUE;
        int winnerIndex=this.noOfPlayers;
        for(int i=1; i<this.noOfPlayers+1; ++i){
            if(winnerChips<this.playerList.get(i).getChips()){
                winnerChips=this.playerList.get(i).getChips();
                winnerIndex=i;
            }
        }
        
        this.sendStatusToAll(this.playerList.get(winnerIndex).getName()+" is winner for this game!");
        this.sendMessageToAll("end!");    
    }
    
    //healper function for sending any meggesge to game players
    private void sendMessageToAll(String _msg){
        for(int i=0; i<this.noOfPlayers; ++i){
            this.playerList.get(i).sendMessage("message!");
            this.playerList.get(i).sendMessage(_msg);
        }
    }
    
    private void sendMessageToAllExcept(String _msg, int _i){//_i => user whome to not send message
        for(int i=0; i<this.noOfPlayers; ++i){
            if(i!=_i){
                this.playerList.get(i).sendMessage("message!");
                this.playerList.get(i).sendMessage(_msg);
            }
        }
    }
    
    //healper function for sending status to game players
    private void sendStatusToAll(String _msg){
        for(int i=0; i<this.noOfPlayers; ++i){
            this.playerList.get(i).sendMessage("status!");
            this.playerList.get(i).sendStatus(_msg);
        }
    }
    
    public void addPlayer(BlackJackPlayer _player){
        this.playerList.add(_player);
    }
    
    public boolean checkPlayerNameAvailability(String _name){
        for(int i=0; i<this.playerList.size(); ++i){
            if(playerList.get(i).getName().equals(_name))
                return false;//if name is already taken by another player
        }
        
        return true;//if name not exist
    }
    
    
    //it will reset cards of deck
    public void resetPlayersState(){
        for(int i=0; i<this.noOfPlayers+1; ++i){
            this.playerList.get(i).resetState();
        }
    }
    
    public boolean getIsGameEnd(){
        return this.isGameEnd;
    }
    
    public void sendMessageToCreator(String _msg){
        this.playerList.get(0).sendMessage("message!");
        this.playerList.get(0).sendMessage(_msg+" Joined the game");
    }
}
