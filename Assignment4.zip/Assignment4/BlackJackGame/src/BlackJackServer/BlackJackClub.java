package BlackJackServer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;

public class BlackJackClub {
    private ServerSocket serverSocket;
    private HashMap<String, BlackJackGame> gamesContainer;     //gamesContainer stores all running  games
    public BlackJackClub(ServerSocket _serverSocket){
        this.serverSocket=_serverSocket;
        this.gamesContainer=new HashMap<>();
    }

    /*
        this is our main thread and is always available to welcome new connection
    */
    public void openClub() throws IOException{
        while(true){
            new HandleNewPlayer(serverSocket.accept()).run();//listining to client and assign it to the handler
        }
    }
    
    /*
        This function has responsibility of handling new players and also creating/joning the game.
    */
    private class HandleNewPlayer extends Thread{
        private Socket socket;//This socket belongs to new client
        BufferedReader is;//input from socket
        PrintWriter os;//output to socket
        public HandleNewPlayer(Socket _socket) throws IOException{
            this.socket=_socket;
            this.is=new BufferedReader(new InputStreamReader(socket.getInputStream()));
            this.os=new PrintWriter(socket.getOutputStream(),true);
        }
        
        @Override
        public void run(){
            try{
                String msg=this.is.readLine();
                if(msg.equals("1")){
                    this.startNewGame();
                }
                else if(msg.equals("2")){
                    this.joinTheGame();
                }
            }
            catch(Exception e){
                e.printStackTrace();
            }
        }
        
        private void startNewGame() throws IOException{
            String gameName;
            boolean isNameAvailable;
            int noOfPlayers=Integer.parseInt(this.is.readLine());//reading no of players from client
            //This loop ensure the uniquenes of gameName
            do{
                gameName=this.is.readLine();
                isNameAvailable=gamesContainer.containsKey(gameName);
                if(isNameAvailable)
                {
                    if(!gamesContainer.get(gameName).getIsGameEnd())
                        this.os.println("Invalid name!");//sending invalid response to client (game creator)
                    else{
                        gamesContainer.remove(gameName);
                        isNameAvailable=false;//make it false because game is removed from the container
                    }
                }
            }while(isNameAvailable);
            
            gamesContainer.put(gameName, new BlackJackGame(noOfPlayers, gameName));
            this.os.println("Game created!");//Sending response to client that game is created (game creator)
            String playerName=is.readLine();//reading name of client (game creator)
            this.os.println("name available!");//as it is the first player in the game
            gamesContainer.get(gameName).addPlayer(new BlackJackPlayer(playerName, this.socket, this.os, this.is));//adding player to game
            this.os.println("Waiting for "+(noOfPlayers-1)+" other players to join...");
            gamesContainer.get(gameName).start();//Starting thread for new game
        }
        
        private void joinTheGame() throws IOException{
            String gameName;
            String playerName;
            boolean isNameAvailable;
            //This loop ensure the valid name of gameName
            do{
                gameName=this.is.readLine();
                isNameAvailable=gamesContainer.containsKey(gameName);
                if(!isNameAvailable)//if game not exist
                    this.os.println("Invalid name!");//sending invalid response to client (game creator)
            }while(!isNameAvailable);
            
            this.os.println("Game available!");
            BlackJackGame game=gamesContainer.get(gameName);
            //This loop ensure the valid name of player
            do{
                playerName=this.is.readLine();
                isNameAvailable=game.checkPlayerNameAvailability(playerName);
                if(!isNameAvailable)//if game not exist
                    this.os.println("Invalid name!");//sending invalid response to client (game creator)
            }while(!isNameAvailable);
            
            this.os.println("name available!");
            game.addPlayer(new BlackJackPlayer(playerName, this.socket, this.os, this.is));//adding player to game
            game.sendMessageToCreator(playerName);
        }
    }
}
