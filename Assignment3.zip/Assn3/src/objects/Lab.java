package objects;

//lab extends GeneralObject because it has the exact same member variables as deliverables
public class Lab extends GeneralObject{
}
